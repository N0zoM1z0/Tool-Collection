#ifndef _SHM_H
#define _SHM_H

#include <stddef.h>

void *shm_create(size_t size);

#endif

