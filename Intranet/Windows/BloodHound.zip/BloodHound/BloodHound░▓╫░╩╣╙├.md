参考这篇：[内网渗透工具bloodhound安装及使用_bloodhound使用-CSDN博客](https://blog.csdn.net/qq_56426046/article/details/126854991)

# 简介

> BloodHound是一款可视化图形分析域环境中的关系的工具，以用图与线的形式，将域内用户、计算机、组、Sessions、ACLs以及域内所有相关用户、组、计算机、登陆信息、访问控制策略之间的关系更直观的展现在红队人员面前进行更便捷的分析域内情况，更快速的在域内提升自己的权限。它也可以使蓝队成员对己方网络系统进行更好的安全检测及保证域的安全性。
>
> Neo4j是一款NOSQL图形数据库，它将结构化数据存储在网络上而不是表中，Bloodhound利用这种特性加以合理分析，可以更加直观的将数据以节点空间”来表达相关数据。BloodHound通过在域内导出相关信息，在将数据收集后，将其导入Neo4j数据库中，进行展示分析。
>



在实战复杂的域环境中，如果能BloodHound信息收集转成这种拓扑图，能够很好分析出整个内网环节的薄弱点。



# 安装

## neo4j安装

kali先安装neo4j数据库：

```
apt install neo4j
```

然后

```
neo4j start
```

![image-20240820103714671](./BloodHound安装使用/images/image-20240820103714671.png)

启动后，浏览器访问：`http://localhost:7474`

默认账密：neo4j/neo4j

![image-20240820103815223](./BloodHound安装使用/images/image-20240820103815223.png)



连接后会让改密码。

这里改为

```
neo4j
123456
```

就可以进去了。



## BloodHound安装

选择这个tag的安装：[Release BloodHound 4.0.3 · BloodHoundAD/BloodHound (github.com)](https://github.com/BloodHoundAD/BloodHound/releases/tag/4.0.3)

解压到kali下，启动

```
./BloodHound --no-sandbox
```

然后弹出来这个界面：

![image-20240820104807745](./BloodHound安装使用/images/image-20240820104807745.png)

登录即可。



# BloodHound使用

> BloodHound需要来自Active Directory（AD）环境的三条信息才能运行：
>
> - 哪些用户登录了哪些机器
> - 哪些用户拥有管理员权限
> - 哪些用户和组属于哪些组
>
> 在大多数情况下，收集此信息不需要管理员权限，也不需要在远程系统上执行代码。



## BloodHound数据收集

> 在本地安装 BloodHound GUI 4.0.3 完成后，需要进行数据的采集与导入，数据的采集可以使用 ps1 脚本或者使用 exe 程序收集，需要使用对应版本的数据采集工具。

注意下版本要对应。

https://github.com/BloodHoundAD/BloodHound/tree/4.0.3/Collectors

下载好后，上传到域内主机即可信息收集。(需要目标主机有对应版本的.NET环境)

对应powershell升级的安装： [Download Windows Management Framework 5.1 from Official Microsoft Download Center](https://www.microsoft.com/en-us/download/details.aspx?id=54616)

```
# 二进制采集工具命令：
SharpHound.exe -c all
# powershell采集工具命令：
powershell -exec bypass -command "Import-Module ./SharpHound.ps1; Invoke-BloodHound -c all"
```

![image-20240820112013986](./BloodHound安装使用/images/image-20240820112013986.png)

采集成功后，会生成一个基于时间命名的zip文件，此文件保存了采集到的域环境数据信息。

![image-20240820112050077](./BloodHound安装使用/images/image-20240820112050077.png)



## BloodHound数据导入

> 将数据采集完生成的zip文件，上传导入到BloodHound分析。

![image-20240820112450811](./BloodHound安装使用/images/image-20240820112450811.png)



导入后等一会儿，或者退出再进入就可以看到拓扑图了：

![image-20240820112718830](./BloodHound安装使用/images/image-20240820112718830.png)

![image-20240820112821516](./BloodHound安装使用/images/image-20240820112821516.png)



## BloodHound关系说明

(本地存个档)

> 在每个节点与节点之间都有对应的关系，分别代表着不同的意思。

![image-20240820113032893](./BloodHound安装使用/images/image-20240820113032893.png)

> **HasSession**
> 当用户与计算机进行会话时，凭据会保留在内存中，可用 LSASS 注入或者凭据转储来获取用户凭据。
>
> **MemberOf**
> MemberOf 表示组的成员，此节点是上一节点的成员，由末端指向上的尖端。
>
> **AdminTo**
> AdminTo 末端是尖端的本地管理员，本地管理员对这台计算机的管理权限比较大，下面的这个用户组是前一台计算机的本地管理员。
>
> **ACL Edges**
> AllExtendedRights 扩展权限是授予对象的特殊权限，这些对象允许读取特权属性以及执行特殊操作；如果对象是用户，则可以重置用户密码；如果是组，则可以修改组成员；如果是计算机，则可以对该计算机执行基于资源的约束委派。
> AddMember 可以向目标安全组添加任意成员。
> ForceChangePassword 可以任意重置目标用户密码。
> **GenericAll** 可以完全控制目标对象。
> GenericWrite 写入权限，修改目标的属性或者将主体添加入组等。
> Owns 保留修改 security descriptors 的能力，会忽略DACL权限的限制。
> WriteDacl 可写入目标DACL，修改DACL访问权。
> WriteOwner 保留修改 security descriptors。 的能力，会忽略DACL权限的限制。
> ReadLAPSPassword 读取LAPS上的本地管理员凭证。
> ReadGMSAPassword 读取GMSA上的本地管理员凭证。
>
> **Containers**
> Contains 可以在OU上添加一个新的ACE，它将继承到该OU下的所有子对象上，比如说在OU上应用GenericAll ACE ，那么所有子对象都将继承GenericAll属性。
> GpLink 将其设置为链接容器中的对象。
>
> **特殊 Edges**
> CanRDP 用远程桌面进行会话。
> CanPSRemote 用PowerShell进行会话。
> ExecuteDCOM 实例化目标的COM对象并调用其方法，可以在特定条件下执行代码。
> AllowedToDelegate 有这个特权的节点可以将任何域主体(包括Domain Admins)模拟到目标主机上的特定服务。
> AddAllowedToAct 可以控制任意的安全主体伪装为特定计算机的任何域用户。
> AllowedToAct 可以使用此用户滥用S4U2self / S4U2proxy进程，将任何域用户模拟到目标计算机系统，并以“该用户”身份接收有效的服务票证。
> SQLAdmin 该用户是目标计算机的MSSQL管理员。
> HasSIDHistory 用户的SID历史记录，用户在域迁移后，票据还包含着前域所在组的SID，虽然用户不属于前域，但仍拥有前域的权限。