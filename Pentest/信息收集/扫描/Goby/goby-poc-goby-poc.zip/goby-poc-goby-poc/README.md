# goby-poc
#   声明
包含447个自定义goby-poc，是否含有后门和重复自行判断，如果无红队版，可直接poc管理处导入自定义poc即可，共计745个。
![图片](https://user-images.githubusercontent.com/74171727/185719401-f4782b47-157b-48db-87df-955a65adc487.png)


本程序仅供于学习交流，请使用者遵守《中华人民共和国网络安全法》，勿将此脚本用于非授权的测试，脚本开发者不负任何连带法律责任。

Goby POC 仅仅只供对已授权的目标使用测试，对未授权目标的测试，本库不承担责任，均由使用者自行承担。


## ✦✦Star上升曲线✦✦

[![Stargazers over time](https://starchart.cc/MY0723/goby-poc.svg)](https://starchart.cc/MY0723/goby-poc)

