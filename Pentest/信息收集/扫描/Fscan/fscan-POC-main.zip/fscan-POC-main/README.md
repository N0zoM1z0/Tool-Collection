# fscan-POC
强化fscan的漏扫POC库

声明：该POC仅供于学习跟安全检测使用，如果违法&恶意操作，与本人无关！！！欢迎关注chaosec公众号

如果有师傅想加的漏洞POC可以公众号或者项目评论告诉我

一、使用说明：

将fscan项目拉取到本地，然后找到路径\fscan\WebScan\pocs\，将该项目的.yml文件放入该路径重新打包fscan即可食用

fscan项目地址：https://github.com/shadow1ng/fscan

二、更新：

2022.4.10 

add CVE-2022-22947-spring-clond-Gateway-RCE.yml

2022.4.11

add CVE-2021-22005-vmcenter-upload-toRCE.yml

add CVE-2021-21972-vmcenter-RCE.yml

2022.4.12

add CVE-2022-22954-VMware-RCE.yml

2022.4.18

del CVE-2022-22965-spring4shell-RCE.yml

add CVE-2022-22963-Spring-SpEL-RCE.yml

add CVE-2017-7504-Jboss-serialization-RCE.yml

2022.05.28

修复了一些问题

感谢Whale3070师傅指出错误，并且给出修改建议

![image](https://user-images.githubusercontent.com/75511051/162608378-f4abbb55-0271-4fe1-9296-f3e83f07555a.png)

会持续更新!!!

