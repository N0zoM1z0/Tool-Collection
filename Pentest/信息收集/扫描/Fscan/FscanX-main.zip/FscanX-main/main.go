package main

import (
	"FscanX/core"
)
func main(){
	core.GetFlags()
}
